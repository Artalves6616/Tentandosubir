# Descrição
Avaliação Parcial 1

## Curso e Instituição
Curso de Administração e Economia do IBMEC - Brasília.

## Disciplina
Essa é uma avaliação fornecida para disciplina Progamação para Análise de Dados do 2o.Semestre de 2024.

## Professor
Laerte Jun Takeuti, MsC \
email: laerte.takeuti@professores.ibmec.edu.br \


## Aluno